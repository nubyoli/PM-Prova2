/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova2.pm;

/**
 *
 * @author 1638220
 */
public class Carro extends Veiculo implements Avaliavel {
    private final int portas;
    private final Avaliacoes avaliacoes = new Avaliacoes();

    public Carro(String placa, String modelo, int anoFabricacao, double valorDiaria, int quilometragem, int portas, StatusVeiculo status) {
        super(placa, modelo, anoFabricacao, valorDiaria, quilometragem, status);
        this.portas = portas;
    }

    @Override
    public void exibirDetalhes() {
        System.out.println(portas + " portas" + " | " + avaliacoes);
    }

    @Override
    public void avaliar(int nota) { avaliacoes.adicionar(nota); }

    @Override
    public boolean possuiSeguroEspecial() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
