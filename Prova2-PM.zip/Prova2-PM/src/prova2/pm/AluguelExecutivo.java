/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova2.pm;

/**
 *
 * @author 1638220
 */
public class AluguelExecutivo extends Aluguel implements Avaliavel {
    private final Avaliacoes avaliacoes = new Avaliacoes();
    
    public AluguelExecutivo(String nomeCliente, int quantidadeDias, double valorTotal, StatusAluguel status) { 
        super(nomeCliente, quantidadeDias, valorTotal, status); 
    }
    
    @Override
    public void avaliar(int nota) { avaliacoes.adicionar(nota); }

    @Override
    public String toString() { return super.toString() + " | " + avaliacoes; }

    @Override
    public void exibirDetalhes() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean possuiSeguroIncluso() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
