/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova2.pm;

import java.time.LocalDate;

/**
 *
 * @author 1638220
 */
public class Van extends Veiculo implements Avaliavel, Inspecionavel {
    private final int passageiros;
    private final Avaliacoes avaliacoes = new Avaliacoes();
    private LocalDate ultimaInspecao;
    
    public Van(String placa, String modelo, int anoFabricacao, double valorDiaria, int quilometragem, int passageiros, StatusVeiculo status) {
        super(placa, modelo, anoFabricacao, valorDiaria, quilometragem, status);
        this.passageiros = passageiros;
    }
    
    @Override
    public void exibirDetalhes() {
        System.out.println("Passageiros: " + passageiros + "Avaliações" + avaliacoes + " Ultima inspeção: "  + ultimaInspecao);
    }
    
    @Override
    public void avaliar(int nota) { avaliacoes.adicionar(nota); }

    @Override
    public boolean possuiSeguroEspecial() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void realizarInspecao() {
        ultimaInspecao = LocalDate.now();
        System.out.println("Inspeção registrada em " + ultimaInspecao + ".");    
    }
    
    
}
