/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova2.pm;

import java.time.LocalDate;

/**
 *
 * @author 1638220
 */
public class Moto extends Veiculo implements Inspecionavel {
    private final int cilindrada;
    private LocalDate ultimaInspecao;
    
    public Moto(String placa, String modelo, int anoFabricacao, double valorDiaria, int quilometragem, int cilindrada, StatusVeiculo status) {
        super(placa, modelo, anoFabricacao, valorDiaria, quilometragem, status);
        this.cilindrada = cilindrada;
    }
    
    @Override
    public void exibirDetalhes() {
        System.out.println("Cilindradas: " + cilindrada + " Ultima inspeção: " + ultimaInspecao);
    }
    
    @Override
    public boolean possuiSeguroEspecial() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void realizarInspecao() {
        ultimaInspecao = LocalDate.now();
        System.out.println("Inspeção registrada em " + ultimaInspecao + ".");    }
}
