/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova2.pm;

import java.util.IntSummaryStatistics;

/**
 *
 * @author 1638220
 */
public class Avaliacoes {
    private final IntSummaryStatistics notas = new IntSummaryStatistics();

    void adicionar(int nota) {
        if (nota < 1 || nota > 5) throw new IllegalArgumentException("Informe uma nota de 1 a 5.");
        notas.accept(nota);
        System.out.println("Avaliação registrada.");
    }

    @Override
    public String toString() {
        return notas.getCount() == 0 ? "sem avaliações" : String.format("média %.1f", notas.getAverage());
    }
}
