/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prova2.pm;

/**
 *
 * @author 1638220
 */
public class Prova2PM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Carro carro = new Carro("ABC1D23", "Onix", 2024, 140.00, 25000, 4, StatusVeiculo.DISPONIVEL);
        Moto moto = new Moto("DEF4G56", "Factor", 2023, 70.00, 12000, 150, StatusVeiculo.DISPONIVEL);
        Van van = new Van("GHI7J89", "Sprinter", 2025, 320.00, 18000, 15, StatusVeiculo.DISPONIVEL);
        
        //AluguelBasico basico = new AluguelBasico();
        //Auguelexecutivo executivo = new AluguelBasico();
    }
    
}
